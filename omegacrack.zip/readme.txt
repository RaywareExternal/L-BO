How to use Rust Hack v2311 Nutser.club
Download an injector (Process Hacker 2 or Extreme Injector) (or any injector might work!)
Start the Rust v2311 game. (Maybe as admin)
Start injector (as admin??)
Add Nutser.club.dll and inject.
Enjoy

=====================================================

Ghost Cheetos! Discord Server Links,

[+] https://pastebin.com/LBxQyS9k

Go To Pastebin Link And Join Our Discord!

=====================================================